/* 
En este script encontrarás todos los comandos que ejecutaremos durante el desarrollo de nuestro entrenamiento

¡Muchos éxitos en tus estudios!
*/
