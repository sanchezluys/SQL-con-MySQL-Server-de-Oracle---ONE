/*
En este notebook encontrarás todos los comandos SQL que ejecutaremos durante el desarrollo del entrenamiento. 

¡Te deseo éxito en tus estudios!
*/
