CREATE USER 'admin02'@'localhost' IDENTIFIED BY 'admin02';

GRANT ALL PRIVILEGES ON *.* TO 'admin02'@'localhost' WITH GRANT OPTION;