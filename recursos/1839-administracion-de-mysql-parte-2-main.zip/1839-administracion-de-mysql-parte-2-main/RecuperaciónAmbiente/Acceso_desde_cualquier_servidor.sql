CREATE USER 'admingeneric02'@'%' IDENTIFIED BY 'admingeneric02';

GRANT ALL PRIVILEGES ON *.* TO 'admingeneric02'@'%' WITH GRANT OPTION;