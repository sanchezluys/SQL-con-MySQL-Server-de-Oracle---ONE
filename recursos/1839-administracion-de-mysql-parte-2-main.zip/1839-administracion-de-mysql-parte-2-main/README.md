# 1839-administracion-de-mysql-parte-2

Notebook con comandos sql del curso de Administración de MySQL: Seguridad y optimización de la base de datos - Parte 2 de Alura en español.
